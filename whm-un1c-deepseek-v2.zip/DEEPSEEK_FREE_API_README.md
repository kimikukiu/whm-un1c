# DeepSeek Free API Integration for WHOAMISEC PRO

This update integrates the [DeepSeek Free API](https://github.com/LLM-Red-Team/deepseek-free-api) into the WHOAMISEC PRO platform, allowing you to use high-performance DeepSeek models (V3 & R1) for free via a reverse proxy.

## 🚀 Supported Models

The following models are now available in the **Settings > AI Configuration** panel:

| Model ID | Description |
|----------|-------------|
| `deepseek` | **DeepSeek-V3** (Default) |
| `deepseek-r1` | **DeepSeek-R1** (Deep Thinking / Reasoning) |
| `deepseek-search` | DeepSeek with **Internet Search** enabled |
| `deepseek-r1-search` | DeepSeek-R1 with **Internet Search** enabled |
| `deepseek-think-silent` | Deep thinking mode (no reasoning output) |
| `deepseek-r1-silent` | DeepSeek-R1 (no reasoning output) |
| `deepseek-search-silent` | Internet search (no search result output) |
| `deepseek-think-fold` | Thinking process wrapped in `<details>` tags |
| `deepseek-r1-fold` | R1 thinking process wrapped in `<details>` tags |

## 🛠️ Configuration

1. **Endpoint URL**: Point this to your `deepseek-free-api` instance.
   - Local: `http://localhost:8000/v1/chat/completions`
   - Remote: `https://your-proxy-server.com/v1/chat/completions`
2. **User Token**: Your DeepSeek `userToken` (obtained from `chat.deepseek.com` LocalStorage).
3. **Model Selection**: Choose your preferred model from the dropdown menu in the settings panel.

## 📦 Deployment to Vercel

To update your deployment at `https://full-whm-exp-67w7.vercel.app/`:

### 1. Update your GitHub Repo
Push the updated files to your repository:
```bash
git add .
git commit -m "Integrate DeepSeek Free API with full model support"
git push origin main
```

### 2. Configure Vercel Environment Variables
In your Vercel Project Settings, add these variables if you want them as defaults:
- `VITE_DEEPSEEK_FREE_ENDPOINT`: `https://your-api-server.com/v1/chat/completions`
- `VITE_DEEPSEEK_FREE_KEY`: `your_user_token`

### 3. Automatic Redeploy
Vercel will automatically trigger a new build. Once finished, the new DeepSeek Free provider will be available in the UI.

## 🐳 Running the API Proxy (Optional)
If you haven't deployed the `deepseek-free-api` proxy yet, you can run it via Docker:
```bash
docker run -d \
  --name deepseek-free-api \
  -p 8000:8000 \
  -e PROXY_KEY=optional_key \
  vinlic/deepseek-free-api:latest
```

---
*Note: This integration uses reverse-engineered endpoints. Use responsibly and in accordance with DeepSeek's terms of service.*
