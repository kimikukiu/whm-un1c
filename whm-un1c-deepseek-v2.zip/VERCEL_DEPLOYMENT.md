# Vercel Deployment Guide

This guide explains how to deploy the WHOAMISEC PRO application with DeepSeek Free API integration to Vercel.

## Prerequisites

- GitHub account with the updated repository
- Vercel account (free tier available)
- DeepSeek Free API running on a public server
- Node.js 18+ (for local testing)

## Step 1: Prepare Your Repository

### 1.1 Update Your GitHub Repository

```bash
cd /path/to/whm-un1c
git add .
git commit -m "Add DeepSeek Free API integration and deployment guides"
git push origin main
```

### 1.2 Verify Files

Ensure these files are present in your repository:
- `src/services/aiService.ts` (updated with DeepSeek Free support)
- `src/components/ApiConfigPanel.tsx` (updated with UI)
- `types.ts` (updated with new types)
- `DEEPSEEK_FREE_API_GUIDE.md` (new)
- `docker-compose.deepseek.yml` (new)
- `.env.deepseek.example` (new)
- `vercel.json` (existing, no changes needed)

## Step 2: Deploy DeepSeek Free API

Before deploying to Vercel, ensure your DeepSeek Free API server is running on a public URL.

### Option A: Deploy on a VPS (Recommended)

```bash
# SSH into your VPS
ssh user@your-vps.com

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Clone and run DeepSeek Free API
git clone https://github.com/LLM-Red-Team/deepseek-free-api.git
cd deepseek-free-api

# Create environment file
cat > .env << EOF
PROXY_KEY=your_secure_token_here
PORT=8000
EOF

# Run with Docker Compose
docker-compose up -d
```

### Option B: Use a Cloud Provider

**Railway.app** (Easy, free tier available):
1. Go to https://railway.app
2. Click "New Project"
3. Select "Deploy from GitHub"
4. Choose the deepseek-free-api repository
5. Set environment variables:
   - `PROXY_KEY`: Your authentication token
   - `PORT`: 8000
6. Deploy

**Render.com** (Free tier available):
1. Go to https://render.com
2. Create new "Web Service"
3. Connect GitHub repository
4. Set build command: `npm install`
5. Set start command: `npm start`
6. Add environment variables
7. Deploy

### Option C: Use Heroku (Legacy, but still works)

```bash
# Install Heroku CLI
curl https://cli-assets.heroku.com/install.sh | sh

# Login to Heroku
heroku login

# Create app
heroku create your-deepseek-api

# Set environment variables
heroku config:set PROXY_KEY=your_secure_token_here -a your-deepseek-api

# Deploy
git push heroku main
```

### Verify Your API is Running

```bash
# Test the endpoint
curl -X POST https://your-api-server.com/v1/chat/completions \
  -H "Authorization: Bearer your_secure_token_here" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "deepseek-chat",
    "messages": [{"role": "user", "content": "Hello"}],
    "max_tokens": 100
  }'
```

You should receive a JSON response with the model's reply.

## Step 3: Deploy to Vercel

### 3.1 Connect GitHub Repository

1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Select "Import Git Repository"
4. Choose your GitHub repository (kimikukiu/whm-un1c)
5. Click "Import"

### 3.2 Configure Environment Variables

In the Vercel project settings:

1. Go to **Settings** → **Environment Variables**
2. Add the following variables:

```
VITE_DEEPSEEK_FREE_ENDPOINT=https://your-api-server.com/v1/chat/completions
VITE_DEEPSEEK_FREE_KEY=your_secure_token_here
VITE_DEEPSEEK_MODEL=deepseek-chat
VITE_DEFAULT_AI_PROVIDER=deepseek-free
VITE_ENABLE_GEMINI_FALLBACK=false
VITE_REQUEST_TIMEOUT=30000
```

**Important**: Replace `your-api-server.com` with your actual DeepSeek Free API server URL.

### 3.3 Configure Build Settings

Vercel should auto-detect your configuration from `vercel.json`:

- **Framework**: Vite
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

These are already configured in your `vercel.json` file.

### 3.4 Deploy

1. Click "Deploy"
2. Wait for the build to complete (usually 2-3 minutes)
3. Your app will be available at `https://full-whm-exp-67w7.vercel.app/`

## Step 4: Verify Deployment

### 4.1 Check Application

1. Visit your Vercel URL: https://full-whm-exp-67w7.vercel.app/
2. Navigate to **Settings** → **AI Configuration**
3. Verify "DeepSeek Free" is available as a provider
4. Check that the endpoint URL and token are correctly set

### 4.2 Test Chat

1. Go to **WHOAMISEC GPT** tab
2. Send a test message
3. Verify response comes from DeepSeek Free API

### 4.3 Check Logs

In Vercel dashboard:
1. Go to your project
2. Click **Deployments**
3. Select the latest deployment
4. Click **Logs** to view build and runtime logs

## Step 5: Update Existing Deployment

If you already have a Vercel deployment:

### 5.1 Update Repository

```bash
git add .
git commit -m "Update DeepSeek Free API integration"
git push origin main
```

### 5.2 Vercel Auto-Deploy

Vercel will automatically detect the push and redeploy. Monitor the deployment in the dashboard.

### 5.3 Manual Redeploy (if needed)

1. Go to Vercel dashboard
2. Select your project
3. Click **Deployments**
4. Click the three dots next to the latest deployment
5. Select **Redeploy**

## Configuration Options

### Environment Variables Reference

| Variable | Required | Example | Description |
|----------|----------|---------|-------------|
| `VITE_DEEPSEEK_FREE_ENDPOINT` | Yes | `https://api.example.com/v1/chat/completions` | DeepSeek Free API endpoint |
| `VITE_DEEPSEEK_FREE_KEY` | Yes | `your_token_here` | Authentication token |
| `VITE_DEEPSEEK_MODEL` | No | `deepseek-chat` | Model name |
| `VITE_DEFAULT_AI_PROVIDER` | No | `deepseek-free` | Default provider |
| `VITE_ENABLE_GEMINI_FALLBACK` | No | `false` | Enable Gemini fallback |
| `VITE_GEMINI_API_KEY` | No | `AIza...` | Gemini API key (if fallback enabled) |
| `VITE_REQUEST_TIMEOUT` | No | `30000` | Request timeout in ms |

### Runtime Configuration

Users can also configure settings in the application UI:
1. **Settings** → **AI Configuration**
2. Select **DeepSeek Free** provider
3. Enter endpoint URL
4. Enter authentication token
5. Settings are saved in browser localStorage

## Troubleshooting

### Issue: "Cannot reach API endpoint"

**Causes**:
- DeepSeek Free API server is down
- Endpoint URL is incorrect
- Network connectivity issue

**Solutions**:
1. Verify endpoint URL: `https://your-api-server.com/v1/chat/completions`
2. Test with curl: `curl https://your-api-server.com/health`
3. Check server logs: `docker logs deepseek-free-api`
4. Verify firewall allows HTTPS (port 443)

### Issue: "401 Unauthorized"

**Causes**:
- Invalid authentication token
- Token not set in environment variables
- Token mismatch between client and server

**Solutions**:
1. Verify token in Vercel environment variables
2. Ensure token matches server's `PROXY_KEY`
3. Restart Vercel deployment after updating variables
4. Test token with curl:
   ```bash
   curl -H "Authorization: Bearer YOUR_TOKEN" \
     https://your-api-server.com/health
   ```

### Issue: "Build fails on Vercel"

**Causes**:
- TypeScript errors
- Missing dependencies
- Incompatible Node.js version

**Solutions**:
1. Check build logs in Vercel dashboard
2. Run locally: `npm install && npm run build`
3. Fix any TypeScript errors: `npm run lint`
4. Ensure Node.js version is 18+

### Issue: "Timeout errors in production"

**Causes**:
- DeepSeek Free API is slow
- Network latency
- Large response sizes

**Solutions**:
1. Increase `VITE_REQUEST_TIMEOUT` (in milliseconds)
2. Reduce `max_tokens` in API requests
3. Check DeepSeek Free API server performance
4. Use a CDN or proxy for better latency

## Performance Optimization

### 1. Enable Caching

Add to `vercel.json`:
```json
{
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=60"
        }
      ]
    }
  ]
}
```

### 2. Optimize Bundle Size

```bash
# Analyze bundle
npm install --save-dev vite-plugin-visualizer

# Run analysis
npm run build -- --analyze
```

### 3. Enable Compression

Vercel automatically enables gzip compression.

### 4. Use Edge Functions (Advanced)

For low-latency API calls, consider using Vercel Edge Functions:

```typescript
// api/chat.ts (Edge Function)
export const config = {
  runtime: 'edge',
};

export default async (request: Request) => {
  const body = await request.json();
  
  const response = await fetch(
    process.env.VITE_DEEPSEEK_FREE_ENDPOINT,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.VITE_DEEPSEEK_FREE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    }
  );
  
  return response;
};
```

## Monitoring and Maintenance

### 1. Monitor Deployments

- Set up Vercel notifications in dashboard
- Enable GitHub status checks
- Monitor error rates in Vercel Analytics

### 2. Update Dependencies

```bash
npm update
npm audit fix
git push origin main  # Triggers auto-deploy
```

### 3. Monitor DeepSeek Free API

```bash
# Check server health
curl https://your-api-server.com/health

# View logs
docker logs -f deepseek-free-api

# Monitor resources
docker stats deepseek-free-api
```

### 4. Set Up Alerts

Configure monitoring for:
- API response time
- Error rate
- Uptime
- Resource usage

## Rollback Procedure

If something goes wrong:

1. **Vercel Dashboard**:
   - Go to **Deployments**
   - Click on a previous working deployment
   - Click **Promote to Production**

2. **GitHub**:
   ```bash
   git revert HEAD
   git push origin main
   ```

## Security Best Practices

1. **Never commit secrets**:
   ```bash
   echo ".env.local" >> .gitignore
   ```

2. **Use strong tokens**:
   ```bash
   # Generate secure token
   openssl rand -hex 32
   ```

3. **Enable HTTPS**:
   - Vercel provides free HTTPS
   - Ensure DeepSeek Free API uses HTTPS

4. **Restrict API access**:
   - Use firewall rules on your API server
   - Implement rate limiting
   - Monitor for suspicious activity

5. **Rotate credentials regularly**:
   - Change `PROXY_KEY` monthly
   - Update Vercel environment variables
   - Review access logs

## Advanced Deployment

### Multi-Region Deployment

Deploy DeepSeek Free API in multiple regions for redundancy:

1. Deploy to multiple VPS providers
2. Use a load balancer or DNS failover
3. Configure multiple endpoints in the app

### CI/CD Pipeline

Add GitHub Actions for automated testing:

```yaml
# .github/workflows/deploy.yml
name: Deploy to Vercel

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm install
      - run: npm run lint
      - run: npm run build
      - uses: vercel/action@main
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

## Support and Resources

- **Vercel Documentation**: https://vercel.com/docs
- **Vite Documentation**: https://vitejs.dev
- **DeepSeek Free API**: https://github.com/LLM-Red-Team/deepseek-free-api
- **WHOAMISEC PRO**: https://github.com/kimikukiu/whm-un1c

---

**Last Updated**: March 2026
**Deployment Version**: 1.0
**Vercel Compatibility**: All plans (Free, Pro, Enterprise)
